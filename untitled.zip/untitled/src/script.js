// --- आपकी जानकारी ---
const CREATOR_NAME = "Utkarsh Maurya";
const AI_NAME = "UtkForce AI";

// --- API कॉन्फ़िगरेशन ---
const TEXT_MODEL = 'gemini-2.5-flash-preview-09-2025';
const TTS_MODEL = 'gemini-2.5-flash-preview-tts';
const TTS_VOICE = 'Kore'; 
const apiKey = "AIzaSyCtOpVgfMNtvS5vjV7Jur3m5uJNnHYTnv4"; 

// --- DOM तत्व ---
const chatHistory = document.getElementById('chat-history');
const promptInput = document.getElementById('prompt-input');
const sendButton = document.getElementById('send-button');
const voiceInputBtn = document.getElementById('voice-input-btn');
const uploadImageBtn = document.getElementById('upload-image-btn');
const imageFileInput = document.getElementById('image-file-input');
const removeImageBtn = document.getElementById('remove-image-btn');
const imagePreviewContainer = document.getElementById('image-preview-container');
const imagePreview = document.getElementById('image-preview');
const imageFilename = document.getElementById('image-filename');
const micIcon = document.getElementById('mic-icon');
const loadingMessage = document.getElementById('loading-message');
const errorMessage = document.getElementById('error-message');
const statusArea = document.getElementById('status-area');

let isLoading = false; 
let attachedImage = null; 
let recognition = null; 
let currentAudio = null; 

// --- प्रारंभिक सेटअप ---

// CodePen में window.onload की जगह यह फ़ंक्शन तुरंत चलता है
(function initializeApp() {
     // Lucide Icons को रेंडर करें (यह CodePen में उपलब्ध होना चाहिए)
     if (typeof lucide !== 'undefined' && lucide.createIcons) {
         lucide.createIcons();
     }
     createMessageBubble(`नमस्ते ${CREATOR_NAME}! ${AI_NAME} में आपका स्वागत है। स्थिरता और गति में सुधार किया गया है। अब बोलकर देखें!`, 'ai');
     setupSpeechRecognition();
})();


// --- TTS यूटिलिटी फ़ंक्शंस ---

function base64ToArrayBuffer(base64) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
}

function pcmToWav(pcm16, sampleRate) {
    const numChannels = 1;
    const bytesPerSample = 2;
    const buffer = new ArrayBuffer(44 + pcm16.length * bytesPerSample);
    const view = new DataView(buffer);
    
    let pos = 0;
    const writeString = (s) => { for (let i = 0; i < s.length; i++) view.setUint8(pos++, s.charCodeAt(i)); };
    const writeUint32 = (i) => { view.setUint32(pos, i, true); pos += 4; };
    const writeUint16 = (i) => { view.setUint16(pos, i, true); pos += 2; };

    writeString('RIFF');
    writeUint32(36 + pcm16.length * bytesPerSample); 
    writeString('WAVE');
    writeString('fmt ');
    writeUint32(16); 
    writeUint16(1); 
    writeUint16(numChannels); 
    writeUint32(sampleRate); 
    writeUint32(sampleRate * numChannels * bytesPerSample); 
    writeUint16(numChannels * bytesPerSample); 
    writeUint16(bytesPerSample * 8); 
    writeString('data');
    writeUint32(pcm16.length * bytesPerSample); 

    pcm16.forEach(sample => {
        view.setInt16(pos, sample, true);
        pos += 2;
    });
    
    return new Blob([buffer], { type: 'audio/wav' });
}

// वॉयस आउटपुट के लिए TTS API कॉल और प्लेबैक
async function fetchTTS(text, audioButton) {
    if (audioButton.disabled) return;
    
    // 1. यदि कोई पिछला ऑडियो चल रहा है, तो उसे रोकें
    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
        currentAudio = null;
    }

    audioButton.disabled = true;
    statusArea.classList.remove('hidden');
    loadingMessage.classList.remove('hidden');
    loadingMessage.textContent = "ऑडियो जेनरेट हो रहा है...";
    
    const originalIcon = audioButton.innerHTML;
    // लोडिंग इंडिकेटर
    audioButton.innerHTML = '<i data-lucide="volume-x" class="w-5 h-5 animate-pulse text-red-500"></i>'; 
    if (typeof lucide !== 'undefined') lucide.createIcons();

    const apiUrlTTS = `https://generativelanguage.googleapis.com/v1beta/models/${TTS_MODEL}:generateContent?key=${apiKey}`;

    try {
        const payload = {
            contents: [{ parts: [{ text: `Say in a smooth, clear Hindi voice: ${text}` }] }],
            generationConfig: {
                responseModalities: ["AUDIO"],
                speechConfig: {
                    voiceConfig: { prebuiltVoiceConfig: { voiceName: TTS_VOICE } } 
                }
            },
            model: TTS_MODEL
        };

        const response = await fetchWithExponentialBackoff(payload, apiUrlTTS);
        const result = await response.json();
        
        const part = result?.candidates?.[0]?.content?.parts?.[0];
        const audioData = part?.inlineData?.data;
        const mimeType = part?.inlineData?.mimeType;

        if (audioData && mimeType) {
            const rateMatch = mimeType.match(/rate=(\d+)/);
            const sampleRate = rateMatch ? parseInt(rateMatch[1], 10) : 16000;
            
            const pcmData = base64ToArrayBuffer(audioData);
            const pcm16 = new Int16Array(pcmData);
            const wavBlob = pcmToWav(pcm16, sampleRate);
            const audioUrl = URL.createObjectURL(wavBlob);
            
            currentAudio = new Audio(audioUrl);
            currentAudio.play();
            
            loadingMessage.textContent = "ऑडियो प्ले हो रहा है...";
            
            // आइकॉन को प्लेबैक मोड में बदलें
            audioButton.innerHTML = '<i data-lucide="volume-3" class="w-5 h-5 text-green-600"></i>';
            if (typeof lucide !== 'undefined') lucide.createIcons();

            currentAudio.onended = () => {
                audioButton.disabled = false;
                audioButton.innerHTML = originalIcon;
                statusArea.classList.add('hidden');
                currentAudio = null;
            };
            currentAudio.onerror = (e) => {
                console.error("Audio playback error:", e);
                displayError("ऑडियो चलाने में त्रुटि। शायद ब्राउज़र अनुमति नहीं दे रहा।");
                audioButton.disabled = false;
                audioButton.innerHTML = originalIcon;
                currentAudio = null;
            };
        } else {
            console.error("TTS ऑडियो डेटा नहीं मिला।");
            displayError("TTS ऑडियो डेटा प्राप्त करने में असमर्थ।");
        }

    } catch (error) {
        console.error("TTS Error:", error);
        displayError(`TTS अनुरोध विफल हुआ: ${error.message}`);
    } finally {
        if (audioButton.disabled && currentAudio === null) {
            audioButton.disabled = false;
            audioButton.innerHTML = originalIcon;
            statusArea.classList.add('hidden');
        }
    }
}

// --- यूटिलिटी फ़ंक्शन ---

function scrollChatToBottom() {
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

function createMessageBubble(text, sender, isImage = false, imageUrl = null) {
    const messageWrapper = document.createElement('div');
    messageWrapper.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'}`;

    const messageBubble = document.createElement('div');
    messageBubble.className = `max-w-[85%] p-3 whitespace-pre-line text-sm ${sender === 'user' ? 'user-message' : 'ai-message pr-10'}`;

    if (isImage) {
        const img = document.createElement('img');
        img.src = imageUrl;
        img.className = 'max-w-full h-auto rounded-lg mb-2 shadow-md';
        messageBubble.appendChild(img);
        
        const textNode = document.createTextNode(text);
        messageBubble.appendChild(textNode);
    } else {
         messageBubble.innerHTML = text.replace(/\n/g, '<br>');
    }

    if (sender === 'ai') {
        const audioButton = document.createElement('button');
        audioButton.className = 'icon-btn absolute top-1 right-1 w-8 h-8 p-1 text-indigo-700 hover:text-indigo-900 bg-indigo-100 rounded-full shadow-sm';
        audioButton.innerHTML = '<i data-lucide="volume-2" class="w-5 h-5"></i>';
        audioButton.title = "उत्तर सुनें";
        
        const rawText = text.replace(/<br>/g, ' ').replace(/<[^>]*>?/gm, ''); 
        audioButton.onclick = () => fetchTTS(rawText, audioButton);
        
        messageBubble.appendChild(audioButton);

    }

    messageWrapper.appendChild(messageBubble);
    chatHistory.appendChild(messageWrapper);
    scrollChatToBottom();
    if (typeof lucide !== 'undefined') lucide.createIcons(); 
}

function setLoading(loading) {
    if (currentAudio && !currentAudio.paused) return;

    isLoading = loading;
    const inputHasContent = promptInput.value.trim() !== '' || attachedImage !== null;
    
    sendButton.disabled = loading || !inputHasContent;
    voiceInputBtn.disabled = loading;
    uploadImageBtn.disabled = loading;

    statusArea.classList.toggle('hidden', !loading && errorMessage.classList.contains('hidden'));
    loadingMessage.classList.toggle('hidden', !loading);
    errorMessage.classList.add('hidden');
    loadingMessage.textContent = "AI जवाब जेनरेट कर रहा है...";
    
    if (loading && recognition && recognition.stop) {
        recognition.stop();
    }
}

function displayError(message) {
    if (currentAudio) {
         currentAudio.pause();
         currentAudio = null;
    }
    isLoading = false; 
    sendButton.disabled = false;

    errorMessage.textContent = message;
    errorMessage.classList.remove('hidden');
    statusArea.classList.remove('hidden');
    loadingMessage.classList.add('hidden');
}

async function fetchWithExponentialBackoff(payload, apiUrl, maxRetries = 5) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (response.status === 429 && i < maxRetries - 1) {
                const delay = Math.pow(2, i) * 1000 + Math.random() * 1000;
                await new Promise(resolve => setTimeout(resolve, delay));
                continue; 
            }

            if (!response.ok) {
                const errorBody = await response.json();
                throw new Error(`API Error: ${response.status} - ${errorBody.error?.message || response.statusText}`);
            }

            return response;

        } catch (error) {
            if (i === maxRetries - 1) {
                throw error;
            }
        }
    }
    throw new Error("Maximum retries reached without success.");
}

// --- इमेज हैंडलिंग ---
uploadImageBtn.addEventListener('click', () => { if (!isLoading) imageFileInput.click(); });
imageFileInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file) {
        if (file.size > 5 * 1024 * 1024) { displayError("छवि 5MB से छोटी होनी चाहिए।"); return; }
        const reader = new FileReader();
        reader.onload = (e) => {
            attachedImage = {
                base64: e.target.result.split(',')[1],
                mimeType: file.type
            };
            imagePreview.src = e.target.result;
            imageFilename.textContent = file.name;
            imagePreviewContainer.classList.remove('hidden');
            promptInput.dispatchEvent(new Event('input')); 
        };
        reader.onerror = () => { displayError("फ़ाइल पढ़ने में त्रुटि।"); };
        reader.readAsDataURL(file);
    }
});
removeImageBtn.addEventListener('click', () => {
    attachedImage = null;
    imageFileInput.value = ''; 
    imagePreviewContainer.classList.add('hidden');
    promptInput.dispatchEvent(new Event('input')); 
});


// --- वॉयस इनपुट (Speech Recognition) सेटअप ---
function setupSpeechRecognition() {
    if ('webkitSpeechRecognition' in window) {
        recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.lang = 'hi-IN'; 
        recognition.interimResults = false; 

        recognition.onstart = function() {
            micIcon.setAttribute('data-lucide', 'circle');
            micIcon.classList.add('text-red-500', 'animate-pulse');
            voiceInputBtn.classList.remove('bg-gray-300', 'hover:bg-gray-400');
            voiceInputBtn.classList.add('bg-red-200');
            if (typeof lucide !== 'undefined') lucide.createIcons();
            promptInput.placeholder = 'बोल रहे हैं... (Speaking...)';
        };

        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            promptInput.value = transcript;
            promptInput.dispatchEvent(new Event('input')); 
        };

        recognition.onerror = function(event) {
            if (event.error !== 'no-speech' && event.error !== 'aborted') {
                console.error('Speech Recognition Error:', event.error);
                displayError(`वॉयस इनपुट में त्रुटि: ${event.error}. माइक एक्सेस की अनुमति दें।`);
            }
        };

        recognition.onend = function() {
            micIcon.setAttribute('data-lucide', 'mic');
            micIcon.classList.remove('text-red-500', 'animate-pulse');
            voiceInputBtn.classList.remove('bg-red-200');
            voiceInputBtn.classList.add('bg-gray-300', 'hover:bg-gray-400');
            if (typeof lucide !== 'undefined') lucide.createIcons();
            promptInput.placeholder = 'Type your message... (अपना मैसेज टाइप करें...)';
        };

        voiceInputBtn.addEventListener('click', () => {
            if (isLoading) return;
            try {
                if (micIcon.getAttribute('data-lucide') === 'circle') {
                     recognition.stop();
                } else {
                     recognition.start();
                }
            } catch (e) {
                console.error("Recognition start/stop error:", e);
            }
        });

    } else {
        voiceInputBtn.disabled = true;
        voiceInputBtn.title = "आपका ब्राउज़र वॉयस इनपुट का समर्थन नहीं करता है।";
    }
}


// --- कस्टमाइज़्ड रिस्पॉन्स हैंडलर ---
function handleCustomResponse() {
    setLoading(false);
    const customResponse = `नमस्ते! मेरा नाम ${AI_NAME} है।\n\nमुझे मेरे निर्माता, ${CREATOR_NAME} ने बनाया है। मैं आपकी सहायता करने, दुनिया की जानकारी खोजने, और चित्र देखकर समझने के लिए डिज़ाइन किया गया हूँ।`;
    createMessageBubble(customResponse, 'ai');
}

// --- मुख्य API फ़ंक्शन ---
async function generateResponse() {
    if (isLoading) return;

    const userQuery = promptInput.value.trim();
    if (!userQuery && !attachedImage) return;

    // 1. यूजर का मैसेज चैट हिस्ट्री में जोड़ें
    let displayedQuery = userQuery;
    let imageSource = null;
    if (attachedImage) {
        displayedQuery += userQuery ? `\n\n[संलग्न चित्र पर प्रश्न]` : `[संलग्न चित्र]`;
        imageSource = imagePreview.src;
    }
    createMessageBubble(displayedQuery, 'user', !!attachedImage, imageSource);
    
    // इनपुट क्षेत्र को साफ करें
    promptInput.value = '';
    removeImageBtn.click(); 
    promptInput.dispatchEvent(new Event('input')); 

    setLoading(true);

    // 2. कस्टमाइज़्ड रिस्पॉन्स के लिए चेक करें
    const normalizedQuery = userQuery.toLowerCase().replace(/[?।.,]/g, '').trim();
    const creatorKeywords = ["kisne banaya hai", "tumhe kisne banaya", "apko kisne banaya", "tumhara creator kaun", "tumhare janak kaun"];

    if (!attachedImage && creatorKeywords.some(keyword => normalizedQuery.includes(keyword))) {
        handleCustomResponse();
        return;
    }

    try {
        const systemPrompt = `आप ${AI_NAME} हैं, जो ${CREATOR_NAME} द्वारा निर्मित एक अत्यंत सहायक, जानकार और विनम्र AI सहायक है।
            आप दुनिया की जानकारी तक पहुँच सकते हैं, चित्र समझ सकते हैं, और हमेशा विस्तृत, तथ्यात्मक रूप से सही और रचनात्मक उत्तर हिंदी में प्रदान करेंगे।
            आपके उत्तरों में 'हाँ' या 'ना' शब्द या उनके पर्यायवाची का उपयोग बिल्कुल नहीं होना चाहिए।
            उत्तर को साफ-सुथरे पैराग्राफ या बुलेट पॉइंट्स में फ़ॉर्मेट करें।`;

        const parts = [];
        if (userQuery) {
            parts.push({ text: userQuery });
        }
        if (attachedImage) {
             parts.push({
                inlineData: {
                    mimeType: attachedImage.mimeType,
                    data: attachedImage.base64
                }
            });
        }
        
        const payload = {
            contents: [{ parts: parts }],
            tools: [{ "google_search": {} }], 
            systemInstruction: {
                parts: [{ text: systemPrompt }]
            },
        };

        const apiUrlText = `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`;
        const response = await fetchWithExponentialBackoff(payload, apiUrlText);
        const result = await response.json();
        
        const candidate = result.candidates?.[0];

        if (candidate && candidate.content?.parts?.[0]?.text) {
            const text = candidate.content.parts[0].text;
            createMessageBubble(text, 'ai');

        } else {
            displayError("उत्तर प्राप्त करने में असमर्थ। कृपया फिर से प्रयास करें।");
        }

    } catch (error) {
        console.error("Fetch/API error:", error);
        displayError(`अनुरोध विफल हुआ: ${error.message}`);
    } finally {
        setLoading(false);
    }
}

// --- इवेंट लिसनर ---

// इनपुट फ़ील्ड की ऊँचाई को एडजस्ट करें
promptInput.addEventListener('input', () => {
    const inputHasContent = promptInput.value.trim() !== '' || attachedImage !== null;
    sendButton.disabled = isLoading ? true : !inputHasContent;
    
    promptInput.style.height = 'auto';
    promptInput.style.height = Math.min(promptInput.scrollHeight, 120) + 'px'; 
});

// एंटर या सेंड बटन से मैसेज भेजें
sendButton.addEventListener('click', generateResponse);
promptInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        const inputHasContent = promptInput.value.trim() !== '' || attachedImage !== null;
        if (inputHasContent && !isLoading) {
            generateResponse();
        }
    }
});